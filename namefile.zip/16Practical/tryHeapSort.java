// AI Declaration: Consulted Gemini (Free Version) for task breakdown and structural understanding.
import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.util.ArrayList;

public class tryHeapSort {
    public static void main(String[] args) {
        String[] words = {"joyce", "apple", "zebra", "dublin", "bloom"};

        String[] arr1 = java.util.Arrays.copyOf(words, words.length);
        String[] arr2 = java.util.Arrays.copyOf(words, words.length);

        System.out.println("Original: " + java.util.Arrays.toString(words));
        System.out.println("-------------------------");

        buildBottomUp(arr1);
        heapSort(arr1);
        System.out.println("Sorted (Bottom-Up): " + java.util.Arrays.toString(arr1));

        buildTopDown(arr2);
        heapSort(arr2);
        System.out.println("Sorted (Top-Down):  " + java.util.Arrays.toString(arr2));
        System.out.println("-------------------------\n");


        try {

            Scanner scanner = new Scanner(new File("joyce1922_ulysses.txt"));
            ArrayList<String> wordList = new ArrayList<>();
            while (scanner.hasNext()) {
                wordList.add(scanner.next());
            }
            scanner.close();

            String[] massiveArray = wordList.toArray(new String[0]);

            String[] arrForBottomUp = massiveArray.clone();
            String[] arrForTopDown = massiveArray.clone();

            System.out.println("Loaded " + massiveArray.length + " words from the file.");
            System.out.println("Starting the timing race...\n");

            long startTime1 = System.nanoTime();
            buildBottomUp(arrForBottomUp);
            heapSort(arrForBottomUp);
            long endTime1 = System.nanoTime();

            long durationBottomUp = (endTime1 - startTime1) / 1000000;
            System.out.println("Bottom-Up + Sort took: " + durationBottomUp + " ms");
            
            long startTime2 = System.nanoTime();
            buildTopDown(arrForTopDown);
            heapSort(arrForTopDown);
            long endTime2 = System.nanoTime();

            long durationTopDown = (endTime2 - startTime2) / 1000000;
            System.out.println("Top-Down + Sort took:  " + durationTopDown + " ms");

        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
            System.out.println("Double-check that 'joyce1922_ulysses.txt' is in the exact same folder as your Java file.");
        }
    }

    private static void swap(String[] arr, int i, int j){
        String temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    private static void siftDown(String[] arr, int i, int heapSize){
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < heapSize && arr[left].compareTo(arr[largest]) > 0){
            largest = left;
        }
        if (right < heapSize && arr[right].compareTo(arr[largest]) > 0){
            largest = right;
        }
        if (largest != i){
            swap(arr, i, largest);
            siftDown(arr, largest, heapSize);
        }
    }

    public static void buildBottomUp(String[] arr){
        int n = arr.length;
        for (int i = (n / 2) - 1; i >= 0; i--){
            siftDown(arr, i, n);
        }
    }

    public static void buildTopDown(String[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            insertSiftUp(arr, i);
        }
    }

    public static void heapSort(String[] arr){
        int n = arr.length;
        for (int i = n - 1; i > 0; i--){
            swap(arr, 0, i);
            siftDown(arr, 0, i);
        }
    }

    private static void insertSiftUp(String[] arr, int i) {
        int current = i;
        int parent = (current - 1) / 2;

        while (current > 0 && arr[current].compareTo(arr[parent]) > 0) {
            swap(arr, current, parent);
            current = parent;
            parent = (current - 1) / 2;
        }
    }
}